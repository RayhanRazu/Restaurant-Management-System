# NOTIFY

demo → [https://azzalfauzi.github.io/notify/](https://azzalfauzi.github.io/notify/)